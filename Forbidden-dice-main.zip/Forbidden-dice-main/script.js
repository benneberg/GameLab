// Your JavaScript code here
console.log("Wow, a new TapLet");